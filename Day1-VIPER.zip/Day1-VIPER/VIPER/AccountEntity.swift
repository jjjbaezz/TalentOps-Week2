//
//  AccountEntity.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//

import Foundation

struct AccountEntity{
    let id: String
    let balance: Double
}
