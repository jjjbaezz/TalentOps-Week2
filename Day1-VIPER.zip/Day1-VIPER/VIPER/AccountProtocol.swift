//
//  AccountProtocol.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//

import Foundation

protocol AccountProtocol {
    func fetchBalance(accountId: String)
}
