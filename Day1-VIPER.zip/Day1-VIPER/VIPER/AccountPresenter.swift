//
//  AccountPresenter.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//

import Foundation

// Adaptación del Presenter
class AccountPresenter {
    weak var view: AccountViewInput?
    var interactor: AccountInteractor?
    var router: AccountRouterProtocol?
    func loadBalance(accountId: String) {
        interactor?.fetchBalance(accountId: accountId)
    }
    
  
    func didSelectAccount(account: AccountEntity) {
    }
}


extension AccountPresenter: AccountOutputProtocol {
    func balanceFetched(_ account: AccountEntity) {
        view?.showBalance(String(account.balance))
    }
}
