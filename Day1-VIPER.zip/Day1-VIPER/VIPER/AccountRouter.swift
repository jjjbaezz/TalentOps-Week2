//
//  AccountRouter.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//

import Foundation

import SwiftUI

protocol AccountRouterProtocol: AnyObject {
    associatedtype DestinationView: View
    func navigateToAccountDetail(account: AccountEntity) -> DestinationView
}

class AccountRouter: AccountRouterProtocol {
    
    func navigateToAccountDetail(account: AccountEntity) -> some View {
        return AccountDetailView(account: account)
    }
}
