//
//  AccountDetailView.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//

import Foundation
import SwiftUI

struct AccountDetailView: View {
    let account: AccountEntity
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Detalles de la Cuenta")
                .font(.largeTitle)
            Text("ID: \(account.id)")
                .font(.headline)
            Text("Balance Actual: $\(account.balance, specifier: "%.2f")")
                .font(.subheadline)
        }
        .padding()
        .navigationTitle("Detalle")
    }
}
