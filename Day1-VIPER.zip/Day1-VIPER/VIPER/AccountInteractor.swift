//
//  AccountInteractor.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//

import Foundation

class AccountInteractor: AccountProtocol {
    
    weak var output: AccountOutputProtocol?
    
    func fetchBalance(accountId: String) {
        let account = AccountEntity(id: accountId, balance: 300.0)
    }
}
