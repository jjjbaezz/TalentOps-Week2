//
//  AccountView.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//



import SwiftUI
import Foundation


protocol AccountViewInput: AnyObject {
    func showBalance(_ balanceText: String)
}

protocol AccountViewOutput: AnyObject {
    func viewDidLoad()
}


class AccountViewState: ObservableObject, AccountViewInput {
    
    @Published var balanceText: String = "Cargando..."
    
    func showBalance(_ balanceText: String) {
        DispatchQueue.main.async {
            self.balanceText = "Balance: \(balanceText)"
        }
    }
}


struct AccountView: View {
    
    @StateObject var viewState = AccountViewState()
    
    var output: AccountViewOutput?

    var body: some View {
        VStack {
            Text(viewState.balanceText)
                .font(.largeTitle)
                .padding()
        }
        .onAppear {
            output?.viewDidLoad()
        }
        .navigationTitle("Mi Cuenta")
    }
}
