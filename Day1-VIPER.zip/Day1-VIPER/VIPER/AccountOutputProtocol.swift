//
//  AccountOutputProtocol.swift
//  VIPER
//
//  Created by U48738 on 12/12/25.
//

import Foundation

protocol AccountOutputProtocol {
    func balanceFetched( _ account: AccountEntity)
}
