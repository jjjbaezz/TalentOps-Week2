//
//  ConfirmationViewController.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import Foundation

import UIKit

class ConfirmationViewController: UIViewController {
    
   
    var payment: PaymentEntity?
    
    private let messageLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemGreen
        setupUI()
    }

    private func setupUI() {
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.textColor = .white
        messageLabel.font = .systemFont(ofSize: 18, weight: .bold)
        
        if let payment = payment {
            messageLabel.text = "¡Pago Confirmado!\nID: \(payment.id)\nMonto: \(payment.amount)€\nMoneda: \(payment.currency)"
        }

        view.addSubview(messageLabel)
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            messageLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            messageLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            messageLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            messageLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
}
