//
//  PaymentPresenter.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import Foundation

class PaymentPresenter {
    var router: PaymentRouter?
    
    func paymentProcessed(_ payment: PaymentEntity) {
        router?.navigateToConfirmationView(payment)
    }
}
