//
//  ErrorViewController.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import Foundation

import UIKit

class ErrorViewController: UIViewController {
    
    var message: String?
    
    private let errorLabel = UILabel()
    private let closeButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    private func setupUI() {
        errorLabel.text = message ?? "Ha ocurrido un error inesperado."
        errorLabel.textColor = .systemRed
        errorLabel.textAlignment = .center
        errorLabel.numberOfLines = 0
        
        closeButton.setTitle("Cerrar", for: .normal)
        closeButton.addTarget(self, action: #selector(dismissError), for: .touchUpInside)

        let stack = UIStackView(arrangedSubviews: [errorLabel, closeButton])
        stack.axis = .vertical
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40)
        ])
    }

    @objc private func dismissError() {
        dismiss(animated: true)
    }
}
