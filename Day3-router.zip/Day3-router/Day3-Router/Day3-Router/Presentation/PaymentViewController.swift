//
//  PaymentViewController.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import Foundation


import UIKit

class PaymentViewController: UIViewController {


    var presenter: PaymentPresenter?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }

    private func setupUI() {
        let payButton = UIButton(type: .system)
        payButton.setTitle("Finalizar Pago", for: .normal)
        payButton.addTarget(self, action: #selector(didTapPay), for: .touchUpInside)
        
        
        payButton.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(payButton)
        NSLayoutConstraint.activate([
            payButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            payButton.centerYAnchor.constraint(equalTo: view.centerYAnchor)
        ])
    }

    @objc private func didTapPay() {
        let newPayment = PaymentEntity(id: "1", amount: 100.0, currency: "DOP")

        presenter?.paymentProcessed(newPayment)
    }
}
