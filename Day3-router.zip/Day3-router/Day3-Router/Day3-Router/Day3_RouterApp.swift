//
//  Day3_RouterApp.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import SwiftUI

@main
struct Day3_RouterApp: App {
    var body: some Scene {
        WindowGroup {
            PaymentViewController()
        }
    }
}
