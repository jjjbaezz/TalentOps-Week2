//
//  Day3_RouterApp.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import SwiftUI

import SwiftUI

struct AppNavigationWrapper: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UINavigationController {
        let rootVC = PaymentViewController()
        let presenter = PaymentPresenter()
        let router = PaymentRouter()
        
        rootVC.presenter = presenter
        presenter.router = router
        router.paymentView = rootVC
        
        let navController = UINavigationController(rootViewController: rootVC)
        return navController
    }
    
    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {}
}

@main
struct Day3_RouterApp: App {
    var body: some Scene {
        WindowGroup {
            AppNavigationWrapper() 
                .ignoresSafeArea()
        }
    }
}
