//
//  PaymentEntity.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import Foundation

struct PaymentEntity {
    let id: String
    let amount: Double
    let currency: String
}
