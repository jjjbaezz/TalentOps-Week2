//
//  PaymentRouter.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import Foundation

class PaymentRouter: PaymentRouterInput {
    
    weak var paymentView: PaymentViewController?
    
    func navigateToConfirmationView(_ payment: PaymentEntity) {
        let confirmationView = ConfirmationViewController()
        
        confirmationView.payment = payment
        paymentView?.navigationController?.pushViewController(
            confirmationView,
            animated: true
        )
    }
    
    func navigateToErrorView(error: String) {
        let errorView = ErrorViewController()
        errorView.message = error
        paymentView?.navigationController?.pushViewController(
            errorView,
            animated: true
        )
    }
    
    
}
