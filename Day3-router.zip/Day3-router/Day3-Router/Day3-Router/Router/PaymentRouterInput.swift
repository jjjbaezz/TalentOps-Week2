//
//  PaymentRouterInput.swift
//  Day3-Router
//
//  Created by JUSTIN BAEZ on 12/18/25.
//

import Foundation

protocol PaymentRouterInput {
    func navigateToConfirmationView(_ payment: PaymentEntity)
    func navigateToErrorView(error: String)
}
