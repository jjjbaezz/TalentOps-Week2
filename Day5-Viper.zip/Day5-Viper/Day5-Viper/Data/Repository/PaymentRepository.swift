//
//  PaymentRepository.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ  on 12/19/25.
//

import Foundation


protocol PaymentRepositoryProtocol {
    func save(_ payment: PaymentEntity)
}

class PaymentRepository: PaymentRepositoryProtocol  {
    func save(_ payment: PaymentEntity) {
        print("Proceder con el guardado del pago \(payment)")
    }
}
