//
//  PaymentPresenter.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/19/25.
//

import Foundation


class  PaymentPresenter{
    weak var view: PaymentViewInput?
    var interactor: PaymentInteractorInput?
    var router : PaymentRouterInput?
        
    func processPayment(amount: Double) {
        let payment = PaymentEntity(id: "1", amount: amount, currency: "DOP")
        interactor?.processPayment(payment)
    }
}

extension PaymentPresenter: PaymentInteractorOutput {
    func paymentProcessedSuccessfully(_ payment: PaymentEntity) {
        view?.showSuccess(" \(payment.currency)\(payment.amount) Paid uccessfully")
        router?.navigateToConfirmation(payment: payment)
    }
    
    func paymentProcessingFailed(_ payment: PaymentEntity) {
        view?.showError("Payment Failed")
        router?.navigateToFailed(message: "Payment failed")
    }
    
    
}
