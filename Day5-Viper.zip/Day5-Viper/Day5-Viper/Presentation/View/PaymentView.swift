//
//  PaymentView.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/19/25.
//

import UIKit

protocol PaymentViewInput: AnyObject {
    func showSuccess(_ result: String)
    func showError(_ error: String)
}


class PaymentViewController: UIViewController {
    
    var presenter: PaymentPresenter?
    
    private let amountTextField = UITextField()
    private let sendButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        setupUI()
    }
    
    private func setupUI() {
        let stack = UIStackView(arrangedSubviews: [amountTextField, sendButton])
        stack.axis = .vertical
        stack.spacing = 20
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.widthAnchor.constraint(equalToConstant: 300)
        ])
        
        amountTextField.placeholder = "Monto (RD$)"
        amountTextField.borderStyle = .roundedRect
        amountTextField.keyboardType = .decimalPad
        
        sendButton.setTitle("Procesar Pago", for: .normal)
        sendButton.addTarget(self, action: #selector(didTapSend), for: .touchUpInside)
    }
    
    @objc private func didTapSend() {
        let amount = Double(amountTextField.text ?? "") ?? 0.0
        presenter?.processPayment(amount: amount)
    }
}

extension PaymentViewController: PaymentViewInput {
    func showSuccess(_ result: String) {
        print("Success: \(result)")
    }
    
    func showError(_ message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}


