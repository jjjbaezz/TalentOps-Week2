//
//  ConfirmationView.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/20/25.
//

import UIKit

class ConfirmationViewController: UIViewController {
    
    var payment: PaymentEntity?

    private let statusLabel = UILabel()
    private let detailsLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .systemBackground
        setupUI()
        displayData()
    }

    private func setupUI() {
        statusLabel.font = .boldSystemFont(ofSize: 24)
        statusLabel.text = "¡Pago Confirmado!"
        statusLabel.textAlignment = .center
        
        detailsLabel.numberOfLines = 0
        detailsLabel.textAlignment = .center
        
        let stack = UIStackView(arrangedSubviews: [statusLabel, detailsLabel])
        stack.axis = .vertical
        stack.spacing = 15
        stack.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20)
        ])
    }

    private func displayData() {
        guard let p = payment else { return }
        detailsLabel.text = "Has enviado \(p.amount) \na \(p.currency)"
    }
}
