//
//  PaymentWireFrame .swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/20/25.
//


import UIKit

class PaymentWireframe {
    static func createModule() -> UIViewController {
        let view = PaymentViewController()
        let repository = PaymentRepository()
        let interactor = PaymentInteractor(repository: repository)
        let router = PaymentRouterImpl()
        let presenter = PaymentPresenter()

        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router

        interactor._output = presenter

        view.presenter = presenter
        router.view = view

        return view
    }
}
