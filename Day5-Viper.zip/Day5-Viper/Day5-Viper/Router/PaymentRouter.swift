//
//  PaymentRouter.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/19/25.
//

import Foundation

protocol PaymentRouterInput {
    func navigateToConfirmation(payment: PaymentEntity)
    func navigateToFailed(message: String)
}

class PaymentRouterImpl: PaymentRouterInput {
    
    weak var view: PaymentViewController?
    
    func navigateToConfirmation(payment: PaymentEntity) {
        let confirmationView = ConfirmationViewController()
        confirmationView.payment = payment
        
        view?.navigationController?.pushViewController(confirmationView, animated: true)
        
    }
    
    func navigateToFailed(message: String) {
        let errorView = ErrorViewController()
        errorView.errorMessage = message
        view?.navigationController?.pushViewController(errorView, animated: true)
    }
}
