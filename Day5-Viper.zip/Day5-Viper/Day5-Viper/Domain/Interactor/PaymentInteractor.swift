//
//  PaymentInteractor.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/19/25.
//

import Foundation

protocol PaymentInteractorInput {
    func processPayment(_ payment: PaymentEntity)
}

protocol PaymentInteractorOutput: AnyObject {
    func paymentProcessedSuccessfully(_ payment: PaymentEntity)
    func paymentProcessingFailed(_ payment: PaymentEntity)
}

class PaymentInteractor: PaymentInteractorInput {
    
    weak var _output: PaymentInteractorOutput?
    private let repository: PaymentRepository?
    
    init (
        repository: PaymentRepository
    ){
        self.repository = repository
    }
    
    func processPayment(_ payment: PaymentEntity) {
        print("Proceder con pago de \(payment.amount)\(payment.currency)")
        guard payment.amount > 0 else {
        print("Payment Failed")
        _output?.paymentProcessingFailed(payment)
        return
        }
        
        print( "Payment Successfull")
        repository?.save(payment)
        _output?.paymentProcessedSuccessfully(payment)
    }
    
}
