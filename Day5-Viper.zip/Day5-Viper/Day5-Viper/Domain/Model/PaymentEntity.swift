//
//  PaymentEntity.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/19/25.
//

import Foundation

struct PaymentEntity {
    let id: String
    let amount: Double
    let currency: String
}
