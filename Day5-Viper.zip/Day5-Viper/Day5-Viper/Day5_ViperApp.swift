//
//  Day5_ViperApp.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/19/25.
//

import SwiftUI

struct PaymentViewWrapper: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> UINavigationController {
        let paymentVC = PaymentWireframe.createModule()
        
        let navController = UINavigationController(rootViewController: paymentVC)
        return navController
    }
    
    func updateUIViewController(_ uiViewController: UINavigationController, context: Context) {}
}

@main
struct Day3_RouterApp: App {
    var body: some Scene {
        WindowGroup {
            PaymentViewWrapper()
                .ignoresSafeArea()
        }
    }
}
