//
//  MockPaymentRepository.swift
//  Day5-Viper
//
//  Created by JUSTIN BAEZ on 12/20/25.
//


class MockPaymentRepository: PaymentRepository {
    var savePaymentCalled = false
    var lastSavedPayment: PaymentEntity?
    
    override func save(_ payment: PaymentEntity){
        savePaymentCalled = true
        lastSavedPayment = payment
    }
}


class MockInteractorOutput: PaymentInteractorOutput {
    var successCalled = false
    var failureCalled = false
    var lastErrorMessage: String?
    
    func paymentProcessedSuccessfully(_ payment: PaymentEntity){
        successCalled = true
    }
    
    func paymentProcessingFailed(_ payment: PaymentEntity) {
        failureCalled = true
    }
    
}
