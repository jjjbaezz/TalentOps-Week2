//
//  MockTesting.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import Foundation

class MockPaymentRepository: PaymentRepository {
    var saveCalled = false
    func savePayment(_ payment: Payment) async throws {
        saveCalled = true
        print("Mock: Pago simulado guardado.")
    }
    
    func testPaymentModule() {
        let mockRepo = MockPaymentRepository()
    
        let interactor = PaymentInteractor(repository: mockRepo)
        
        Task {
            try await interactor.executePayment(Payment(id: "1", amount: 100))
        
            assert(mockRepo.saveCalled == true, "El repositorio debería haber sido llamado")
        }
    }
}



