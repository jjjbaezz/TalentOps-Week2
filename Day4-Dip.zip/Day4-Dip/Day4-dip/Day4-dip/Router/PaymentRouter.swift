//
//  PaymentRouter.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import UIKit


protocol PaymentRouterProtocol {
    func navigateToReceipt()
}

class PaymentRouter: PaymentRouterProtocol {
    weak var viewController: UIViewController?
    
    func navigateToReceipt() {
        let receiptVC = UIViewController()
        receiptVC.view.backgroundColor = .systemGreen
        receiptVC.title = "Recibo"
        
        viewController?.navigationController?.pushViewController(receiptVC, animated: true)
    }
}
