//
//  PaymentModuleFactory.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import UIKit

class PaymentModuleFactory {
    static func make(for environment: AppEnvironment) -> UIViewController {
        let repository: PaymentRepository
        
        switch environment {
        case .production:
            repository = CoreDataPaymentRepository()
        case .development, .testing:
            repository = MockPaymentRepository()
        }
        
        let paymentVC = PaymentWireframe.createModule(repository: repository)
        return UINavigationController(rootViewController: paymentVC)
    }
}
