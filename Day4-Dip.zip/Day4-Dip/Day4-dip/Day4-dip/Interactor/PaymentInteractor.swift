//
//  PaymentInteractor.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import Foundation

protocol PaymentInteractorInput {
    func executePayment(_ payment: Payment)
}

protocol PaymentInteractorOutput: AnyObject {
    func paymentDidSave()
}

class PaymentInteractor: PaymentInteractorInput {
    weak var output: PaymentInteractorOutput?
    private let repository: PaymentRepository
    
    init(repository: PaymentRepository) {
        self.repository = repository
    }
    
    func executePayment(_ payment: Payment) {
        Task {
            do {
                try await repository.savePayment(payment)
                await MainActor.run { output?.paymentDidSave() }
            } catch {
                print(error)
            }
        }
    }
}
