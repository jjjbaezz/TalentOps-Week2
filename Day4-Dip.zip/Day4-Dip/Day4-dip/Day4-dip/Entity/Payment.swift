//
//  Payment.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import Foundation

struct Payment {
    let id: String
    let amount: Double
}
