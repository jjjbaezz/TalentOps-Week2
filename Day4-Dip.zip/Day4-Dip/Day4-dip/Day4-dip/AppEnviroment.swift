//
//  AppEnviroment.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import Foundation

enum AppEnvironment {
    case production, development, testing
}
