//
//  PaymentWireFrame.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import Foundation

import UIKit

class PaymentWireframe {
    static func createModule(repository: PaymentRepository) -> UIViewController {
        let view = PaymentViewController()
        let interactor = PaymentInteractor(repository: repository )
        let presenter = PaymentPresenter()
        let router = PaymentRouter()
        
        view.presenter = presenter
        presenter.view = view
        presenter.interactor = interactor
        presenter.router = router
        interactor.output = presenter
        router.viewController = view
        
        return view
    }
}
