//
//  PaymentPresenter .swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import Foundation

class PaymentPresenter: PaymentPresenterInput, PaymentInteractorOutput {
    weak var view: PaymentViewProtocol?
    var interactor: PaymentInteractorInput?
    var router: PaymentRouterProtocol?
    
    func notifySaveClicked(amount: Double) {
        let payment = Payment(id: UUID().uuidString, amount: amount)
        interactor?.executePayment(payment)
    }
    
    func paymentDidSave() {
        router?.navigateToReceipt()
    }
}
