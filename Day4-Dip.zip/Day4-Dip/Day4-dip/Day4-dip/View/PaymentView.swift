//
//  PaymentView.swift
//  Day4-dip
//
//  Created by U48738 on 12/19/25.
//

import UIKit

protocol PaymentViewProtocol: AnyObject {
    var presenter: PaymentPresenterInput? { get set }
}

class PaymentViewController: UIViewController, PaymentViewProtocol {
    var presenter: PaymentPresenterInput?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Pago"
    }
    
    func simulateUserAction() {
        presenter?.notifySaveClicked(amount: 50.0)
    }
}
