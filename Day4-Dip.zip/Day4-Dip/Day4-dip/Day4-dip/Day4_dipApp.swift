//
//  Day4_dipApp.swift
//  Day4-dip
//
//  Created by U48738 on 12/18/25.
//


import SwiftUI

struct PaymentViewWrapper: UIViewControllerRepresentable {
    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {
    }
    
    let environment: AppEnvironment

    func makeUIViewController(context: Context) -> UIViewController {
        return PaymentModuleFactory.make(for: environment)
    }
}

@main
struct Day4_dipApp: App {
    var body: some Scene {
        WindowGroup {
            PaymentViewWrapper(environment: .development)
                .ignoresSafeArea()
        }
    }
}
