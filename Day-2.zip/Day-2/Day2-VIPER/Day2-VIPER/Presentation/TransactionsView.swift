//
//  Day2_VIPERApp.swift
//  Day2-VIPER
//
//  Created by U48738 on 12/15/25.
//

import SwiftUI



struct TransactionListView: View {
    
    @ObservedObject var viewModel: TransactionListViewModel
    
    var body: some View {
        NavigationView {
            VStack {
              
                if viewModel.isLoading {
                    ProgressView("Cargando...")
                }
               
                else if let error = viewModel.errorMessage {
                    Text("Error: \(error)")
                        .foregroundColor(.red)
                        .padding()
                    Button("Reintentar") {
                        viewModel.loadData()
                    }
                }
            
                else if viewModel.transactions.isEmpty {
                    Text("No hay transacciones disponibles.")
                        .foregroundColor(.gray)
                }
                else {
                    List(viewModel.transactions, id: \.self) { transaction in
                        Text(transaction)
                    }
                }
            }
            .navigationTitle("Transacciones")
            .onAppear {
                if viewModel.transactions.isEmpty {
                    viewModel.loadData()
                }
            }
        }
    }
}
