//
//  TransactionsPresenter.swift
//  Day2-VIPER
//
//  Created by U48738 on 12/15/25.
//

import Foundation

protocol TransactionsListViewInput: AnyObject {
    func showTransactions(_ transactions: [String])
    func showError(_ message: String)
}

protocol TransactionsListViewOutput: AnyObject {
    func transactionsFetched(_ transactions: [Transactions])
}


class TransactionListPresenter {
    weak var view: TransactionsListViewInput?
    var interactor: TransactionsListInteractorInput?
    
    func loadTransactions() {
        interactor?.fetchTransactions()
    }
}

extension TransactionListPresenter: TransactionsListViewOutput {
    func transactionsFetched(_ transactions: [Transactions]) {
        let formatted = transactions.map{ "RD$ \($0.amount)"}
        view?.showTransactions(formatted)
    }
}
