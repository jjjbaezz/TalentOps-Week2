//
//  TransactionsListViewModel.swift
//  Day2-VIPER
//
//  Created by U48738 on 12/15/25.
//

import Foundation


class TransactionListViewModel: ObservableObject {
  
    @Published var transactions: [String] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?
    
    var presenter: TransactionListPresenter?

    func loadData() {
        self.isLoading = true
        self.errorMessage = nil
        presenter?.loadTransactions()
    }
}

extension TransactionListViewModel: TransactionsListViewInput {
    
    func showTransactions(_ transactions: [String]) {
        DispatchQueue.main.async {
            self.transactions = transactions
            self.isLoading = false
            self.errorMessage = nil
        }
    }
    
    func showError(_ message: String) {
        DispatchQueue.main.async {
            self.errorMessage = message
            self.isLoading = false
        }
    }
}
