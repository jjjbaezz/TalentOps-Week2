//
//  MockTransactionsListView.swift
//  Day2-VIPER
//
//  Created by U48738 on 12/15/25.
//

import Foundation

class MockTransactionsListView: TransactionsListViewInput {
    
   
    var showTransactionsCalled = false
    var showErrorCalled = false
    var receivedTransactions: [String]?
    var receivedErrorMessage: String?
    
    func showTransactions(_ transactions: [String]) {
        showTransactionsCalled = true
        receivedTransactions = transactions
    }
    
    func showError(_ message: String) {
        showErrorCalled = true
        receivedErrorMessage = message
    }
}

class MockTransactionListInteractor: TransactionsListInteractorInput {
    
    
    var fetchTransactionsCalled = false
    
    func fetchTransactions() {
        fetchTransactionsCalled = true
    }
}
