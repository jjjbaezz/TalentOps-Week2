//
//  TransactionsApp.swift
//  Day2-VIPER
//
//  Created by U48738 on 12/15/25.
//


import SwiftUI

@main
struct TransactionsApp: App {
    var body: some Scene {
        
        let viewModel = TransactionListViewModel()
        
        WindowGroup {
            TransactionListView(viewModel: viewModel )
        }
    }
}
