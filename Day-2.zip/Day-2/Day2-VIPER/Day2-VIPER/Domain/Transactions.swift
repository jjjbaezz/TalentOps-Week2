//
//  Transactions.swift
//  Day2-VIPER
//
//  Created by U48738 on 12/15/25.
//

import Foundation

struct Transactions {
    let id: String
    let amount: Double
}
