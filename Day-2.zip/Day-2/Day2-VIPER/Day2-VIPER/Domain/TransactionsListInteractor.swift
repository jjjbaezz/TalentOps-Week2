//
//  TransactionsListInteractor.swift
//  Day2-VIPER
//
//  Created by U48738 on 12/15/25.
//

import Foundation


protocol TransactionsListInteractorInput {
    func fetchTransactions()
}

protocol TransactionsListInteractorOutput: AnyObject {
    func displayTransactions(_ transactions: [Transactions])
}


class TransactionsListInteractor: TransactionsListInteractorInput {
    
    weak var output: TransactionsListInteractorOutput?
    
    func fetchTransactions() {
        let transactions = [Transactions(id: "1", amount: 100.0)]
        output?.displayTransactions(transactions)
        
    }
}
